import React, { useState } from 'react';
import { Moon, Sun, Download, Mail, Phone, MapPin, Github, Linkedin } from 'lucide-react';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      {/* Navigation */}
      <nav className={`fixed w-full z-10 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Dharmraj Gade</h1>
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-full ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-6">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Mechanical Engineer & Designer
            </h2>
            <p className="text-lg mb-6">
              Passionate about engineering innovation and design excellence
            </p>
            <a
              href="/resume.pdf"
              download
              className={`inline-flex items-center px-6 py-3 rounded-lg ${
                darkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'
              } text-white font-medium`}
            >
              <Download className="mr-2" size={20} />
              Download Resume
            </a>
          </div>
          <div className="md:w-1/2 mt-8 md:mt-0">
            <img
              src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800"
              alt="Engineering Design"
              className="rounded-lg shadow-xl"
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className={`py-12 px-6 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-8">About Me</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <p className="text-lg mb-4">
                My enthusiasm for machines inspired me to pursue a degree in Mechanical Engineering
                and join Team Predators Racing, my college's motorsports team. As a dedicated engineer,
                I specialize in CNC operations, CAD design, and manufacturing processes.
              </p>
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div>
                  <h3 className="font-semibold mb-2">Technical Skills</h3>
                  <ul className="space-y-2">
                    <li>• Catia</li>
                    <li>• Ansys</li>
                    <li>• SAP Software</li>
                    <li>• GD&T</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Soft Skills</h3>
                  <ul className="space-y-2">
                    <li>• Team Management</li>
                    <li>• Leadership</li>
                    <li>• Problem Solving</li>
                    <li>• Communication</li>
                  </ul>
                </div>
              </div>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1581092335397-9583eb92d232?auto=format&fit=crop&w=800"
                alt="Engineering Workshop"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-12 px-6">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-8">Featured Projects</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Project 1 */}
            <div className={`rounded-lg overflow-hidden shadow-lg ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
              <img
                src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800"
                alt="Firebot"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-xl mb-2">Firebot</h3>
                <p className="mb-4">The Autonomous Fire Extinguisher Robot</p>
                <button className={`text-blue-500 hover:text-blue-600 font-medium`}>
                  Read More →
                </button>
              </div>
            </div>

            {/* Project 2 */}
            <div className={`rounded-lg overflow-hidden shadow-lg ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
              <img
                src="https://images.unsplash.com/photo-1581092456972-7d48b2dd7910?auto=format&fit=crop&w=800"
                alt="Ice Plant"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-xl mb-2">Ice Plant Test Rig</h3>
                <p className="mb-4">Maintenance and Testing Project</p>
                <button className={`text-blue-500 hover:text-blue-600 font-medium`}>
                  Read More →
                </button>
              </div>
            </div>

            {/* Project 3 */}
            <div className={`rounded-lg overflow-hidden shadow-lg ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
              <img
                src="https://images.unsplash.com/photo-1581092160562-46d3a4d466b1?auto=format&fit=crop&w=800"
                alt="IoT Project"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-xl mb-2">IoT Water Level Indicator</h3>
                <p className="mb-4">Smart Water Management System</p>
                <button className={`text-blue-500 hover:text-blue-600 font-medium`}>
                  Read More →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className={`py-12 px-6 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-8">Achievements</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className={`p-6 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
              <h3 className="font-bold text-xl mb-4">Certifications</h3>
              <ul className="space-y-2">
                <li>• Autodesk AutoCAD Certification</li>
                <li>• Catia Software Certification</li>
                <li>• NCC 'A' Certificate</li>
              </ul>
            </div>
            <div className={`p-6 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
              <h3 className="font-bold text-xl mb-4">Sports</h3>
              <ul className="space-y-2">
                <li>• District & Zonal Archery Champion</li>
                <li>• Zonal Chess Runner-up</li>
              </ul>
            </div>
            <div className={`p-6 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
              <h3 className="font-bold text-xl mb-4">Leadership</h3>
              <ul className="space-y-2">
                <li>• Co-NCC Secretary (SVPS School)</li>
                <li>• Team Management (PLGPL)</li>
                <li>• Discipline Head (Cultural Event)</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 px-6">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-8">Contact Me</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <div className="space-y-4">
                <a href="mailto:gadedharmraj@gmail.com" className="flex items-center">
                  <Mail className="mr-2" size={20} />
                  gadedharmraj@gmail.com
                </a>
                <a href="tel:8087980797" className="flex items-center">
                  <Phone className="mr-2" size={20} />
                  8087980797
                </a>
                <div className="flex items-center">
                  <MapPin className="mr-2" size={20} />
                  Pune, Maharashtra
                </div>
                <div className="flex space-x-4 mt-6">
                  <a href="#" className={`${darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'}`}>
                    <Github size={24} />
                  </a>
                  <a href="#" className={`${darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'}`}>
                    <Linkedin size={24} />
                  </a>
                </div>
              </div>
            </div>
            <form className="space-y-4">
              <div>
                <label className="block mb-2">Name</label>
                <input
                  type="text"
                  className={`w-full p-2 rounded-lg ${
                    darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-100 border-gray-300'
                  } border`}
                />
              </div>
              <div>
                <label className="block mb-2">Email</label>
                <input
                  type="email"
                  className={`w-full p-2 rounded-lg ${
                    darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-100 border-gray-300'
                  } border`}
                />
              </div>
              <div>
                <label className="block mb-2">Message</label>
                <textarea
                  rows={4}
                  className={`w-full p-2 rounded-lg ${
                    darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-100 border-gray-300'
                  } border`}
                ></textarea>
              </div>
              <button
                type="submit"
                className={`px-6 py-3 rounded-lg ${
                  darkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'
                } text-white font-medium`}
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className={`py-6 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
        <div className="container mx-auto px-6 text-center">
          <p>&copy; 2025 Dharmraj Gade. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;